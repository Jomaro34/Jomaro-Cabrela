# 📖 Dicionário de Cinfães (com PDF.js incluído)

Este repositório contém uma versão online pesquisável do **Dicionário de Cinfães** usando o PDF.js hospedado localmente.

## Estrutura
- `index.html` → Página inicial com iframe do viewer.
- `Dicionario.pdf` → O ficheiro do dicionário (colocar aqui na raiz).
- `pdfjs/` → Pasta com PDF.js (precisas copiar os ficheiros do projeto PDF.js para aqui).

## Como preparar
1. Vai a [pdf.js releases](https://github.com/mozilla/pdf.js/releases).
2. Descarrega o ficheiro `pdfjs-X.Y.Z-dist.zip`.
3. Extrai e copia as pastas `web` e `build` para dentro da pasta `pdfjs/`.

No fim, a estrutura fica:
```
dicionario-site/
├── index.html
├── Dicionario.pdf
├── README.md
└── pdfjs/
    ├── web/
    │   └── viewer.html
    └── build/
```

Depois ativa o GitHub Pages normalmente.
